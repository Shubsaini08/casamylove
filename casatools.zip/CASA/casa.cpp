#include <iostream>
#include <string>
#include <vector>
#include <thread>
#include <mutex>
#include <atomic>
#include <iomanip>
#include <sstream>
#include <openssl/sha.h> // OpenSSL for SHA256
#include <random>
#include <chrono>
#include <fstream>
#include <condition_variable>
#include <queue>

#define MINI_KEY_LENGTH 22
#define MAX_THREADS 16 // Adjust based on system capacity
#define MAX_BUFFER_SIZE 10000 // Buffer size for async logging

std::mutex outputMutex;
std::mutex logMutex;
std::atomic<uint64_t> keysGenerated(0);
std::atomic<uint64_t> validKeysFound(0);
std::condition_variable logCondition;
std::queue<std::string> logQueue;
std::atomic<bool> loggingActive(true);

// Function to compute SHA256 hash
std::string sha256(const std::string &data) {
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256(reinterpret_cast<const unsigned char *>(data.c_str()), data.size(), hash);

    std::ostringstream oss;
    for (int i = 0; i < SHA256_DIGEST_LENGTH; ++i) {
        oss << std::hex << std::setw(2) << std::setfill('0') << (int)hash[i];
    }
    return oss.str();
}

// Function to validate a mini key
bool isValidMiniKey(const std::string &minikey) {
    std::string testKey = minikey + "?";
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256(reinterpret_cast<const unsigned char *>(testKey.c_str()), testKey.size(), hash);
    return hash[0] == 0x00;
}

// Function to generate random mini key
std::string generateRandomMiniKey() {
    static thread_local std::mt19937_64 rng(std::random_device{}());
    static const char charset[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    std::string minikey = "S";
    for (size_t i = 1; i < MINI_KEY_LENGTH; ++i) {
        minikey += charset[rng() % (sizeof(charset) - 1)];
    }
    return minikey;
}

// Worker thread function to generate and validate mini keys
void generateMiniKeys(uint64_t totalKeys, int threadId) {
    while (keysGenerated.load() < totalKeys) {
        std::string minikey = generateRandomMiniKey();
        keysGenerated++;

        if (isValidMiniKey(minikey)) {
            validKeysFound++;
            {
                std::lock_guard<std::mutex> lock(logMutex);
                logQueue.push( minikey);
            }
            logCondition.notify_one();
        }
    }
}

// Logger thread function
void asyncLogger() {
    std::ofstream logFile("valid_keys.log", std::ios::out | std::ios::app);
    while (loggingActive || !logQueue.empty()) {
        std::unique_lock<std::mutex> lock(logMutex);
        logCondition.wait(lock, [] { return !logQueue.empty() || !loggingActive; });
        while (!logQueue.empty()) {
            logFile << logQueue.front() << std::endl;
            std::cout << logQueue.front() << std::endl;
            logQueue.pop();
        }
    }
    logFile.close();
}

int main() {
    uint64_t totalKeys = 1e99; // Total keys to generate
    int numThreads = std::min<int>(std::thread::hardware_concurrency(), MAX_THREADS);

    std::vector<std::thread> threads;
    auto startTime = std::chrono::high_resolution_clock::now();

    // Start logger thread
    std::thread loggerThread(asyncLogger);

    // Launch worker threads
    for (int i = 0; i < numThreads; ++i) {
        threads.emplace_back(generateMiniKeys, totalKeys, i + 1);
    }

    // Wait for all worker threads to complete
    for (auto &t : threads) {
        t.join();
    }

    // Stop logging
    loggingActive = false;
    logCondition.notify_one();
    loggerThread.join();

    auto endTime = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsedTime = endTime - startTime;

    // Print performance metrics
    std::cout << "Total Keys Generated: " << keysGenerated.load() << "\n";
    std::cout << "Valid Keys Found: " << validKeysFound.load() << "\n";
    std::cout << "Elapsed Time: " << elapsedTime.count() << " seconds\n";
    std::cout << "Keys per Second: " << keysGenerated.load() / elapsedTime.count() << "\n";

    return 0;
}
