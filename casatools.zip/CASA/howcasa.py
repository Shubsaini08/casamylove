#!/usr/bin/env python3

import binascii
import os
import hashlib
import sys
import random
import string
import ecdsa
from bitcoinlib.keys import Key

# INFO: https://en.bitcoin.it/wiki/Mini_private_key_format

__b58chars = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz'
__b58base = len(__b58chars)

def b58encode(v):
    long_value = 0
    for i, c in enumerate(v[::-1]):
        long_value += (256 ** i) * c

    result = ''
    while long_value >= __b58base:
        div, mod = divmod(long_value, __b58base)
        result = __b58chars[mod] + result
        long_value = div
    result = __b58chars[long_value] + result

    nPad = 0
    for c in v:
        if c != 0:
            break
        nPad += 1

    return (__b58chars[0] * nPad) + result

def Hash(data):
    return hashlib.sha256(hashlib.sha256(data).digest()).digest()

def EncodeBase58Check(secret):
    hash = Hash(secret)
    return b58encode(secret + hash[0:4])

def process_key(shortkey):
    print("Processing short key: " + shortkey)
    raw_key = hashlib.sha256(shortkey.encode('utf-8'))

    key_data = binascii.unhexlify('80') + raw_key.digest()
    btc_key = EncodeBase58Check(key_data)

    sk = ecdsa.SigningKey.from_string(raw_key.digest(), curve=ecdsa.SECP256k1)
    vk = sk.verifying_key
    pubkey = b'\04' + vk.to_string()

    sha256_pubkey = hashlib.sha256(pubkey).digest()
    ripemd160 = hashlib.new('ripemd160')
    ripemd160.update(sha256_pubkey)
    hashed_public_key = ripemd160.digest()
    btc_address = EncodeBase58Check(b'\x00' + hashed_public_key)

    return btc_key, btc_address

def generate_random_mini_key():
    charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
    while True:
        candidate = 'S' + ''.join(random.choices(charset, k=21))
        if is_valid_mini_key(candidate):
            return candidate

def is_valid_mini_key(mini_key):
    if len(mini_key) != 22 or not mini_key.startswith('S'):
        return False
    hash_result = hashlib.sha256(mini_key.encode('utf-8')).hexdigest()
    return hash_result[:2] == '00'

def derive_private_key(mini_key):
    return hashlib.sha256(mini_key.encode('utf-8')).hexdigest()

def derive_bitcoin_address(private_key):
    key = Key(secret_exponent=int(private_key, 16))
    return key.address()

def generate_and_save_mini_keys_with_addresses(filename, count=10):
    with open(filename, "w") as file:
        for _ in range(count):
            mini_key = generate_random_mini_key()
            private_key = derive_private_key(mini_key)
            btc_key, btc_address = process_key(mini_key)
            
            file.write(f"Mini Key: {mini_key}\n")
            file.write(f"Private Key: {private_key}\n")
            file.write(f"BTC Key: {btc_key}\n")
            file.write(f"BTC Address: {btc_address}\n")
            file.write("-" * 50 + "\n")

def process_keys_from_file(input_file, known_addresses_file, output_file):
    with open(known_addresses_file, 'r') as addr_file:
        known_addresses = set(line.strip() for line in addr_file)

    with open(input_file, 'r') as file, open(output_file, 'w') as result_file:
        for line in file:
            mini_key = line.strip()
            private_key = derive_private_key(mini_key)
            _, btc_address = process_key(mini_key)

            if btc_address in known_addresses:
                result_file.write(f"Found match for Mini Key: {mini_key}\n")
                result_file.write(f"BTC Address: {btc_address}\n")
                result_file.write("-" * 50 + "\n")

if __name__ == "__main__":
    if len(sys.argv) > 2:
        mode = sys.argv[1]
        if mode == "generate":
            output_file = sys.argv[2]
            count = int(sys.argv[3]) if len(sys.argv) > 3 else 10
            generate_and_save_mini_keys_with_addresses(output_file, count)
            print(f"Generated {count} Mini Keys and saved to {output_file}")
        elif mode == "process":
            keys_file = sys.argv[2]
            known_addresses_file = sys.argv[3]
            output_file = sys.argv[4]
            process_keys_from_file(keys_file, known_addresses_file, output_file)
            print(f"Processed keys from {keys_file} and saved results to {output_file}")
        else:
            sys.exit("Invalid mode. Use 'generate' or 'process'.")
    else:
        sys.exit("Usage: python3 script.py <mode> <output_file> [count or input_file known_addresses_file result_file]")