#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <random>
#include <iomanip>
#include <mutex>
#include <atomic>
#include <thread>
#include <sstream>
#include <condition_variable>
#include <openssl/sha.h>
#include <openssl/ripemd.h>
#include <openssl/ec.h>
#include <openssl/evp.h>
#include <spdlog/spdlog.h>

#define MINI_KEY_LENGTH 22
#define OUTPUT_FILE "FOUNDcasa.txt"

// Global variables
std::mutex outputMutex;
std::atomic<uint64_t> totalKeysGenerated(0);
std::mutex bufferMutex;
std::vector<std::string> resultBuffer;

// Function to generate random mini key
std::string generateRandomMiniKey() {
    static thread_local std::mt19937_64 rng(std::random_device{}());
    static const char charset[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    std::string minikey = "S";
    for (size_t i = 1; i < MINI_KEY_LENGTH; ++i) {
        minikey += charset[rng() % (sizeof(charset) - 1)];
    }
    return minikey;
}

// Function to compute SHA-256 hash
std::vector<unsigned char> sha256(const std::vector<unsigned char>& input) {
    std::vector<unsigned char> hash(SHA256_DIGEST_LENGTH);
    SHA256(input.data(), input.size(), hash.data());
    return hash;
}

// Function to compute RIPEMD-160 hash
std::vector<unsigned char> ripemd160(const std::vector<unsigned char>& input) {
    std::vector<unsigned char> hash(RIPEMD160_DIGEST_LENGTH);
    EVP_MD_CTX* context = EVP_MD_CTX_new();
    if (!context) {
        throw std::runtime_error("Failed to create EVP_MD_CTX");
    }

    if (EVP_DigestInit_ex(context, EVP_ripemd160(), nullptr) != 1 ||
        EVP_DigestUpdate(context, input.data(), input.size()) != 1 ||
        EVP_DigestFinal_ex(context, hash.data(), nullptr) != 1) {
        EVP_MD_CTX_free(context);
        throw std::runtime_error("RIPEMD-160 hash computation failed");
    }

    EVP_MD_CTX_free(context);
    return hash;
}

// Function to derive private key from mini key
std::vector<unsigned char> derivePrivateKey(const std::string& minikey) {
    std::vector<unsigned char> hash(SHA256_DIGEST_LENGTH);
    SHA256(reinterpret_cast<const unsigned char*>(minikey.c_str()), minikey.size(), hash.data());
    return hash;
}

// Function to derive public key from private key
std::vector<unsigned char> derivePublicKey(const std::vector<unsigned char>& privateKey, bool compressed = true) {
    EC_KEY* ecKey = EC_KEY_new_by_curve_name(NID_secp256k1);
    if (!ecKey) throw std::runtime_error("Failed to create EC key");

    BIGNUM* privKeyBN = BN_bin2bn(privateKey.data(), privateKey.size(), nullptr);
    if (!privKeyBN || !EC_KEY_set_private_key(ecKey, privKeyBN)) {
        EC_KEY_free(ecKey);
        BN_free(privKeyBN);
        throw std::runtime_error("Failed to set private key");
    }

    EC_POINT* pubKeyPoint = EC_POINT_new(EC_KEY_get0_group(ecKey));
    if (!pubKeyPoint || !EC_POINT_mul(EC_KEY_get0_group(ecKey), pubKeyPoint, privKeyBN, nullptr, nullptr, nullptr)) {
        EC_KEY_free(ecKey);
        BN_free(privKeyBN);
        EC_POINT_free(pubKeyPoint);
        throw std::runtime_error("Failed to derive public key");
    }

    std::vector<unsigned char> publicKey;
    if (compressed) {
        publicKey.resize(33); // Compressed key length
        EC_POINT_point2oct(EC_KEY_get0_group(ecKey), pubKeyPoint, POINT_CONVERSION_COMPRESSED, publicKey.data(), publicKey.size(), nullptr);
    } else {
        publicKey.resize(65); // Uncompressed key length
        EC_POINT_point2oct(EC_KEY_get0_group(ecKey), pubKeyPoint, POINT_CONVERSION_UNCOMPRESSED, publicKey.data(), publicKey.size(), nullptr);
    }

    EC_KEY_free(ecKey);
    BN_free(privKeyBN);
    EC_POINT_free(pubKeyPoint);
    return publicKey;
}

// Function to compute RIPEMD-160 hash from public key
std::vector<unsigned char> computeRipemdFromPubKey(const std::vector<unsigned char>& privateKey, bool compressed) {
    auto publicKey = derivePublicKey(privateKey, compressed);
    auto shaHash = sha256(publicKey);
    return ripemd160(shaHash);
}

// Function to convert byte array to hex string
std::string toHexString(const std::vector<unsigned char>& input) {
    std::ostringstream oss;
    for (unsigned char byte : input) {
        oss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(byte);
    }
    return oss.str();
}

// Function to write results to file in buffered batches
void writeBufferedResultsToFile() {
    std::lock_guard<std::mutex> lock(bufferMutex);
    if (!resultBuffer.empty()) {
        std::ofstream outputFile(OUTPUT_FILE, std::ios::app); // Open file in append mode
        if (outputFile.is_open()) {
            for (const auto& result : resultBuffer) {
                outputFile << result << std::endl;
            }
        } else {
            spdlog::error("Unable to open output file: " + std::string(OUTPUT_FILE));
        }
        resultBuffer.clear();
    }
}

// Function to process keys for a thread
void processKeysForThread(uint64_t keysToGenerate, uint64_t threadId, uint64_t numThreads) {
    uint64_t startIndex = (keysToGenerate / numThreads) * threadId;
    uint64_t endIndex = (keysToGenerate / numThreads) * (threadId + 1);

    std::vector<std::string> localBuffer;

    for (uint64_t i = startIndex; i < endIndex; ++i) {
        std::string miniKey;
        do {
            miniKey = generateRandomMiniKey();
        } while (miniKey.empty()); // Generate valid mini key

        auto privateKey = derivePrivateKey(miniKey);

        // Generate compressed and uncompressed hashes
        auto compressedHash = computeRipemdFromPubKey(privateKey, true);
        auto uncompressedHash = computeRipemdFromPubKey(privateKey, false);

        std::string compressedHashHex = toHexString(compressedHash);
        std::string uncompressedHashHex = toHexString(uncompressedHash);

        std::string result = miniKey + "," + toHexString(privateKey) + "," + compressedHashHex + "," + uncompressedHashHex;

        // Add result to local buffer
        localBuffer.push_back(result);

        totalKeysGenerated++;

        // Flush to global buffer when local buffer reaches 10000 entries
        if (localBuffer.size() >= 10000) {
            std::lock_guard<std::mutex> lock(bufferMutex);
            resultBuffer.insert(resultBuffer.end(), localBuffer.begin(), localBuffer.end());
            localBuffer.clear();
        }
    }

    // After thread finishes, write any remaining results
    if (!localBuffer.empty()) {
        std::lock_guard<std::mutex> lock(bufferMutex);
        resultBuffer.insert(resultBuffer.end(), localBuffer.begin(), localBuffer.end());
    }
}

// Function to run multi-threaded processing
void runMultiThreadedProcessing(uint64_t keysToGenerate, uint64_t numThreads) {
    std::vector<std::thread> threads;

    for (uint64_t i = 0; i < numThreads; ++i) {
        threads.push_back(std::thread(processKeysForThread, keysToGenerate, i, numThreads));
    }

    // Join threads
    for (auto& th : threads) {
        th.join();
    }

    // Write remaining results after all threads finish
    writeBufferedResultsToFile();
}

int main() {
    uint64_t keysToGenerate = 100000000000000000000; // Define how many keys to generate
    uint64_t numThreads = std::thread::hardware_concurrency(); // Use maximum available threads

    // Start multi-threaded processing
    runMultiThreadedProcessing(keysToGenerate, numThreads);

    std::cout << "Total Keys Generated: " << totalKeysGenerated.load() << std::endl;
    return 0;
}

