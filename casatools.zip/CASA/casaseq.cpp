#include <iostream>
#include <string>
#include <vector>
#include <thread>
#include <mutex>
#include <atomic>
#include <iomanip>
#include <sstream>
#include <openssl/sha.h> // OpenSSL for SHA256
#include <chrono>
#include <fstream>
#include <condition_variable>

const std::string VALID_KEY_PREFIX = "00";  // Prefix for valid keys
#define BASE_MINI_KEY "S0000000000001815393111" // Base key format
#define MAX_BUFFER_SIZE 1000 // Buffer size for async logging
#define CONFIG_FILE "config.txt" // Configuration file

std::mutex logMutex;
std::atomic<uint64_t> keysGenerated(0);
std::atomic<uint64_t> validKeysFound(0);
std::atomic<uint64_t> globalIndex(0);
std::condition_variable logCondition;
std::atomic<bool> loggingActive(true);

// Function to compute SHA256 hash
std::string sha256(const std::string &data) {
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256(reinterpret_cast<const unsigned char *>(data.c_str()), data.size(), hash);

    std::ostringstream oss;
    for (int i = 0; i < SHA256_DIGEST_LENGTH; ++i) {
        oss << std::hex << std::setw(2) << std::setfill('0') << (int)hash[i];
    }
    return oss.str();
}

// Function to validate mini key
bool isValidMiniKey(const std::string &minikey) {
    std::string hash = sha256(minikey);
    return hash.substr(0, VALID_KEY_PREFIX.length()) == VALID_KEY_PREFIX;
}

// Worker thread function to generate and validate mini keys
void generateMiniKeys(uint64_t totalKeys, int threadId, std::ofstream &logFile) {
    auto lastReportTime = std::chrono::high_resolution_clock::now();
    while (true) {
        uint64_t index = globalIndex.fetch_add(1);
        if (index >= totalKeys) break;

        // Generate key based on the index
        std::string minikey = BASE_MINI_KEY;
        uint64_t tempIndex = index;
        for (int j = minikey.size() - 1; j >= 1; --j) {
            minikey[j] = '0' + (tempIndex % 10);
            tempIndex /= 10;
        }

        keysGenerated++;

        // Validate key
        if (isValidMiniKey(minikey)) {
            {
                std::lock_guard<std::mutex> lock(logMutex);
                logFile << minikey << std::endl;
                validKeysFound++;
            }
        }

        // Print performance metrics every 10 seconds
        auto currentTime = std::chrono::high_resolution_clock::now();
        if (std::chrono::duration_cast<std::chrono::seconds>(currentTime - lastReportTime).count() >= 10) {
            lastReportTime = currentTime;
            std::cout << "Total Keys Generated: " << keysGenerated.load() << "\n";
            std::cout << "Valid Keys Found: " << validKeysFound.load() << "\n";
            std::cout << "Elapsed Time: " << std::chrono::duration_cast<std::chrono::seconds>(currentTime.time_since_epoch()).count() << " seconds\n";
            std::cout << "Keys per Second: " << keysGenerated.load() / std::chrono::duration_cast<std::chrono::seconds>(currentTime.time_since_epoch()).count() << "\n";
        }
    }
}

// Load configuration
void loadConfiguration(uint64_t &totalKeys, int &numThreads) {
    std::ifstream configFile(CONFIG_FILE);
    if (configFile.is_open()) {
        std::string line;
        while (std::getline(configFile, line)) {
            if (line.find("totalKeys=") == 0) {
                totalKeys = std::stoull(line.substr(10));
            } else if (line.find("numThreads=") == 0) {
                numThreads = std::stoi(line.substr(11));
            }
        }
        configFile.close();
    }
    if (numThreads <= 0) {
        numThreads = std::thread::hardware_concurrency();
    }
}

int main() {
    uint64_t totalKeys = 1e12; // Default total keys to generate
    int numThreads = std::thread::hardware_concurrency();

    // Load configuration
    loadConfiguration(totalKeys, numThreads);

    std::vector<std::thread> threads;
    auto startTime = std::chrono::high_resolution_clock::now();

    std::ofstream logFile("valid_keys.log", std::ios::out | std::ios::app);

    // Launch worker threads
    for (int i = 0; i < numThreads; ++i) {
        threads.emplace_back(generateMiniKeys, totalKeys, i + 1, std::ref(logFile));
    }

    // Wait for all worker threads to complete
    for (auto &t : threads) {
        t.join();
    }

    logFile.close();

    auto endTime = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsedTime = endTime - startTime;

    // Print performance metrics
    std::cout << "Total Keys Generated: " << keysGenerated.load() << "\n";
    std::cout << "Valid Keys Found: " << validKeysFound.load() << "\n";
    std::cout << "Elapsed Time: " << elapsedTime.count() << " seconds\n";
    std::cout << "Keys per Second: " << keysGenerated.load() / elapsedTime.count() << "\n";

    return 0;
}
