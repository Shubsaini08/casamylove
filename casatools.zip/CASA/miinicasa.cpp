#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_set>
#include <random>
#include <iomanip>
#include <mutex>
#include <atomic>
#include <thread>
#include <sstream>
#include <chrono>
#include <openssl/sha.h>
#include <openssl/ripemd.h>
#include <openssl/ec.h>
#include <openssl/evp.h>
#include <cxxopts.hpp>
#include <spdlog/spdlog.h>

#define MINI_KEY_LENGTH 22
#define FOUND_FILE "FOUNDcasa.txt"
#define GENERATED_FILE "generated.txt"
#define STATS_INTERVAL_MS 1000

// Global variables
std::mutex outputMutex;
std::atomic<uint64_t> totalKeysGenerated(0);
std::atomic<size_t> keysGeneratedLastInterval(0);
std::atomic<bool> matchFound(false);
std::unordered_set<std::string> hashDatabase;
std::mutex bufferMutex;
std::vector<std::string> resultBuffer;
std::atomic<bool> running(true);

// Function to load RIPEMD-160 hash database
void loadHashDatabase(const std::string& filePath) {
    std::ifstream file(filePath);
    if (!file.is_open()) {
        throw std::runtime_error("Failed to open database file: " + filePath);
    }

    std::string line;
    while (std::getline(file, line)) {
        hashDatabase.insert(line);
    }
    spdlog::info("Loaded {} hashes from database.", hashDatabase.size());
}

// Function to generate random mini key
std::string generateRandomMiniKey() {
    static thread_local std::mt19937_64 rng(std::random_device{}());
    static const char charset[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    std::string minikey = "S";
    for (size_t i = 1; i < MINI_KEY_LENGTH; ++i) {
        minikey += charset[rng() % (sizeof(charset) - 1)];
    }
    return minikey;
}

// Function to compute SHA-256 hash
std::vector<unsigned char> sha256(const std::vector<unsigned char>& input) {
    std::vector<unsigned char> hash(SHA256_DIGEST_LENGTH);
    SHA256(input.data(), input.size(), hash.data());
    return hash;
}

// Function to compute RIPEMD-160 hash
std::vector<unsigned char> ripemd160(const std::vector<unsigned char>& input) {
    std::vector<unsigned char> hash(RIPEMD160_DIGEST_LENGTH);
    EVP_MD_CTX* context = EVP_MD_CTX_new();
    if (!context) {
        throw std::runtime_error("Failed to create EVP_MD_CTX");
    }

    if (EVP_DigestInit_ex(context, EVP_ripemd160(), nullptr) != 1 ||
        EVP_DigestUpdate(context, input.data(), input.size()) != 1 ||
        EVP_DigestFinal_ex(context, hash.data(), nullptr) != 1) {
        EVP_MD_CTX_free(context);
        throw std::runtime_error("RIPEMD-160 hash computation failed");
    }

    EVP_MD_CTX_free(context);
    return hash;
}

// Function to derive private key from mini key
std::vector<unsigned char> derivePrivateKey(const std::string& minikey) {
    std::vector<unsigned char> hash(SHA256_DIGEST_LENGTH);
    SHA256(reinterpret_cast<const unsigned char*>(minikey.c_str()), minikey.size(), hash.data());
    return hash;
}

// Function to derive public key from private key
std::vector<unsigned char> derivePublicKey(const std::vector<unsigned char>& privateKey, bool compressed = true) {
    EC_KEY* ecKey = EC_KEY_new_by_curve_name(NID_secp256k1);
    if (!ecKey) throw std::runtime_error("Failed to create EC key");

    BIGNUM* privKeyBN = BN_bin2bn(privateKey.data(), privateKey.size(), nullptr);
    if (!privKeyBN || !EC_KEY_set_private_key(ecKey, privKeyBN)) {
        EC_KEY_free(ecKey);
        BN_free(privKeyBN);
        throw std::runtime_error("Failed to set private key");
    }

    EC_POINT* pubKeyPoint = EC_POINT_new(EC_KEY_get0_group(ecKey));
    if (!pubKeyPoint || !EC_POINT_mul(EC_KEY_get0_group(ecKey), pubKeyPoint, privKeyBN, nullptr, nullptr, nullptr)) {
        EC_KEY_free(ecKey);
        BN_free(privKeyBN);
        EC_POINT_free(pubKeyPoint);
        throw std::runtime_error("Failed to derive public key");
    }

    std::vector<unsigned char> publicKey;
    if (compressed) {
        publicKey.resize(33); // Compressed key length
        EC_POINT_point2oct(EC_KEY_get0_group(ecKey), pubKeyPoint, POINT_CONVERSION_COMPRESSED, publicKey.data(), publicKey.size(), nullptr);
    } else {
        publicKey.resize(65); // Uncompressed key length
        EC_POINT_point2oct(EC_KEY_get0_group(ecKey), pubKeyPoint, POINT_CONVERSION_UNCOMPRESSED, publicKey.data(), publicKey.size(), nullptr);
    }

    EC_KEY_free(ecKey);
    BN_free(privKeyBN);
    EC_POINT_free(pubKeyPoint);
    return publicKey;
}

// Function to compute RIPEMD-160 hash from public key
std::vector<unsigned char> computeRipemdFromPubKey(const std::vector<unsigned char>& privateKey, bool compressed) {
    auto publicKey = derivePublicKey(privateKey, compressed);
    auto shaHash = sha256(publicKey);
    return ripemd160(shaHash);
}

// Function to convert byte array to hex string
std::string toHexString(const std::vector<unsigned char>& input) {
    std::ostringstream oss;
    for (unsigned char byte : input) {
        oss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(byte);
    }
    return oss.str();
}

// Function to write results to file in buffered batches
void writeBufferedResultsToFile(const std::string& filename) {
    std::lock_guard<std::mutex> lock(bufferMutex);
    if (!resultBuffer.empty()) {
        std::ofstream outputFile(filename, std::ios::app); // Open file in append mode
        if (outputFile.is_open()) {
            for (const auto& result : resultBuffer) {
                outputFile << result << std::endl;
            }
        } else {
            spdlog::error("Unable to open output file: {}", filename);
        }
        resultBuffer.clear();
    }
}

// Function to display stats periodically
void displayStats() {
    while (running.load()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(STATS_INTERVAL_MS));

        size_t keysInInterval = keysGeneratedLastInterval.exchange(0);
        size_t totalKeys = totalKeysGenerated.load();

        spdlog::info("####################################################");
        spdlog::info("Generated Keys (Last Interval): {} keys/s", keysInInterval);
        spdlog::info("Total Keys Generated: {}", totalKeys);
    }
}

// Function to process keys for a thread
void processKeysForThread(uint64_t keysToGenerate, uint64_t threadId, uint64_t numThreads, uint64_t keysPerSecond, bool saveAll) {
    uint64_t startIndex = (keysToGenerate / numThreads) * threadId;
    uint64_t endIndex = (keysToGenerate / numThreads) * (threadId + 1);

    std::vector<std::string> localBuffer;

    for (uint64_t i = startIndex; i < endIndex && !matchFound.load(); ++i) {
        if (keysPerSecond > 0 && i % keysPerSecond == 0) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }

        std::string miniKey;
        do {
            miniKey = generateRandomMiniKey();
        } while (miniKey.empty()); // Generate valid mini key

        auto privateKey = derivePrivateKey(miniKey);

        // Generate compressed and uncompressed hashes
        auto compressedHash = computeRipemdFromPubKey(privateKey, true);
        auto uncompressedHash = computeRipemdFromPubKey(privateKey, false);

        std::string compressedHashHex = toHexString(compressedHash);
        std::string uncompressedHashHex = toHexString(uncompressedHash);

        std::string result = miniKey + "," + toHexString(privateKey) + "," + compressedHashHex + "," + uncompressedHashHex;

        // Check for matches in the database
        if (hashDatabase.find(compressedHashHex) != hashDatabase.end() ||
            hashDatabase.find(uncompressedHashHex) != hashDatabase.end()) {
            matchFound.store(true);
            {
                std::lock_guard<std::mutex> lock(outputMutex);
                std::ofstream foundFile(FOUND_FILE, std::ios::app);
                if (foundFile.is_open()) {
                    foundFile << result << std::endl;
                }
            }
            spdlog::info("Match found: {}", result);
        }

        if (saveAll) {
            localBuffer.push_back(result);
        }

        totalKeysGenerated++;
        keysGeneratedLastInterval++;

        if (localBuffer.size() >= 1000) {
            std::lock_guard<std::mutex> lock(bufferMutex);
            resultBuffer.insert(resultBuffer.end(), localBuffer.begin(), localBuffer.end());
            localBuffer.clear();
        }
    }

    // Flush remaining results
    if (!localBuffer.empty()) {
        std::lock_guard<std::mutex> lock(bufferMutex);
        resultBuffer.insert(resultBuffer.end(), localBuffer.begin(), localBuffer.end());
    }
}

// Function to run multi-threaded processing
void runMultiThreadedProcessing(uint64_t keysToGenerate, uint64_t numThreads, uint64_t keysPerSecond, bool saveAll) {
    std::vector<std::thread> threads;

    for (uint64_t i = 0; i < numThreads; ++i) {
        threads.emplace_back(processKeysForThread, keysToGenerate, i, numThreads, keysPerSecond, saveAll);
    }

    std::thread statsThread(displayStats);

    for (auto& th : threads) {
        th.join();
    }

    running.store(false);
    statsThread.join();

    if (saveAll) {
        writeBufferedResultsToFile(GENERATED_FILE);
    }
}

int main(int argc, char** argv) {
    try {
        cxxopts::Options options("KeyGenMatcher", "Generate and match RIPEMD-160 hashes against a database");

        options.add_options()
            ("d,database", "Path to RIPEMD-160 hash database file", cxxopts::value<std::string>())
            ("t,threads", "Number of threads", cxxopts::value<uint64_t>()->default_value("4"))
            ("s,speed", "Keys per second (rate limit, optional)", cxxopts::value<uint64_t>()->default_value("0"))
            ("g,generate", "Total keys to generate", cxxopts::value<uint64_t>()->default_value("100000000000000000000"))
            ("f,save", "Save all generated keys and hashes to file")
            ("h,help", "Print help");

        auto result = options.parse(argc, argv);

        if (result.count("help")) {
            std::cout << options.help() << std::endl;
            return 0;
        }

        if (!result.count("database")) {
            throw std::runtime_error("Database file is required. Use -d to specify the path.");
        }

        std::string databaseFile = result["database"].as<std::string>();
        uint64_t numThreads = result["threads"].as<uint64_t>();
        uint64_t keysPerSecond = result["speed"].as<uint64_t>();
        uint64_t keysToGenerate = result["generate"].as<uint64_t>();
        bool saveAll = result.count("save") > 0;

        spdlog::info("Loading hash database from: {}", databaseFile);
        loadHashDatabase(databaseFile);

        spdlog::info("Starting multi-threaded processing with {} threads", numThreads);

        auto startTime = std::chrono::steady_clock::now();

        runMultiThreadedProcessing(keysToGenerate, numThreads, keysPerSecond, saveAll);

        auto endTime = std::chrono::steady_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::seconds>(endTime - startTime).count();

        spdlog::info("Total keys generated: {}", totalKeysGenerated.load());
        spdlog::info("Time elapsed: {} seconds", duration);

        return 0;
    } catch (const std::exception& e) {
        spdlog::error("Error: {}", e.what());
        return 1;
    }
}
